<template>
    <el-drawer
        :with-header="false"
        :visible="drawer"
        direction="rtl"
        size="50%"
        @close="$emit('close')"
    >
        <div class="flex flex-col p-4">
            <div class="text-lg">Export my RO-Crate</div>
            <div class="mt-6 mb-4">A crate can be exported as a Zip archive or a BagIt Bag.</div>
            <div class="flex flex-col my-4">
                <div>Please select a location to save the export.</div>
                <div class="my-2">
                    <el-button @click="selectFolder">
                        <i class="fas fa-folder-open"></i> select folder
                    </el-button>
                </div>
            </div>
            <div class="flex flex-row">
                <el-radio v-model="exportType" label="zip">Zip Archive</el-radio>
                <el-radio v-model="exportType" label="bag">BagIt Bag</el-radio>
            </div>
            <div class="my-2">{{folder}}</div>
        </div>
    </el-drawer>
</template>

<script>
import { debounce } from "lodash";
import { remote } from "electron";

export default {
    props: {
        drawer: {
            type: Boolean,
            required: true
        }
    },
    data() {
        return { folder: undefined, exportType: "zip" };
    },
    methods: {
        async selectFolder() {
            let folder = await remote.dialog.showOpenDialog({
                properties: ["openDirectory"]
            });
            this.folder = folder.filePaths[0];
            console.log(this.folder);
        }
    }
};
</script>

<style lang="scss" scoped>
</style>
